<?php include_once("include/session.php");?>
<?php include_once("include/db_connect.php");?>
<?php include_once("include/functions.php");?>
<?php $token = $_SESSION["token"]; ?>
<?php  
if($token=isset($_POST["token"])){
  
    $user_id            = test_input($_POST["user_id"]);
    $b_name             = test_input($_POST["b_name"]);
    $b_mobile           = test_input($_POST["b_mobile"]);
    $b_est_year         = test_input($_POST["b_est_year"]);
    $b_address          = test_input($_POST["b_address"]);
    $b_district         = test_input($_POST["b_district"]);
    $b_state            = test_input($_POST["b_state"]);
    $b_pincode          = test_input($_POST["b_pincode"]);
    $b_udyog_no         = test_input($_POST["b_udyog_no"]);
    $b_premises         = test_input($_POST["b_premises"]);
    $b_nature_operation = test_input($_POST["b_nature_operation"]);
    $b_unit_type        = test_input($_POST["b_unit_type"]);
    $b_nature_of_job    = test_input($_POST["b_nature_of_job"]);
    $b_employment_type  = test_input($_POST["b_employment_type"]);
    $b_vendor           = test_input($_POST["b_vendor"]);
    $b_supplier         = test_input($_POST["b_supplier"]);
   

    $add      = add_new_audit($con,$user_id,$b_name,$b_mobile,$b_est_year,$b_address,$b_district,$b_state,$b_pincode,$b_udyog_no,$b_premises,$b_nature_operation,$b_unit_type,$b_nature_of_job,$b_employment_type,
                              $b_vendor,$b_supplier);

    if($add !=null){  
      $response =true;
      $message  ='Audit completed successfully';
      $data     =$tem;
    } 
    else{ 

      $response =false;
      $message  ='Something went wrong';
      $data     =null;
   }

  $response= array('Response'=>$response,'Message'=>$message,'Data'=>$data);
  echo json_encode($response); 

 
}  
                  
?>