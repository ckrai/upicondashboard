<?php include_once("include/session.php");?>
<?php include_once("include/db_connect.php");?>
<?php include_once("include/functions.php");?>
<?php $token = $_SESSION["token"]; ?>
<?php  
if($token=isset($_POST["token"])){
  
    $user_id     = test_input($_POST["user_id"]);
    $status      = test_input($_POST["status"]);
     $role      = test_input($_POST["role"]);

    $getList     = get_applications($con,$user_id,$status,$role);

    if($getList->rowCount() > 0){  
                
      while($row[] =$getList->fetch(PDO::FETCH_ASSOC)) {$tem =$row;}

      $response =true;
      $message  ='Application list';
      $data     =$tem;
    } 
    else{ 

      $response =false;
      $message  ='Application list not found';
      $data     =null;
   }

  $response= array('Response'=>$response,'Message'=>$message,'Data'=>$data);
  echo json_encode($response); 

 
}  
                  
?>