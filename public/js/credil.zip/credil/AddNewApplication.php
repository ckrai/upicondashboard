<?php include_once("include/session.php");?>
<?php include_once("include/db_connect.php");?>
<?php include_once("include/functions.php");?>
<?php $token = $_SESSION["token"]; ?>
<?php  
if($token=isset($_POST["token"])){
  
    $user_id      = test_input($_POST["user_id"]);
    $ro_code      = test_input($_POST["ro_code"]);
    $first_name   = test_input($_POST["first_name"]);
    $last_name    = test_input($_POST["last_name"]);
    $father_name  = test_input($_POST["father_name"]);
    $mobile       = test_input($_POST["mobile"]);
    $dob          = test_input($_POST["dob"]);
    $gender       = test_input($_POST["gender"]);
    $marital      = test_input($_POST["marital"]);
    $category     = test_input($_POST["category"]);
    $minority     = test_input($_POST["minority"]);
    $pwd          = test_input($_POST["pwd"]);
    $aadhaar      = test_input($_POST["aadhaar"]);
    $voter        = test_input($_POST["voter"]);
    $locality     = test_input($_POST["locality"]);
    $village      = test_input($_POST["village"]);
    $district     = test_input($_POST["district"]);
    $state        = test_input($_POST["state"]);
    $pincode      = test_input($_POST["pincode"]);
    $same_district= test_input($_POST["same_district"]);
    $same_state   = test_input($_POST["same_state"]);

    $add      = add_new_application($con,$user_id,$ro_code,$first_name,$last_name,$father_name,$gender,$dob,$marital,$mobile,$category,$minority,$pwd,$aadhaar,$voter,$locality,$village,$district,$state,$pincode,$same_district,$same_state);

    if($add !=null){  
      $response =true;
      $message  ='Application summited. Please fill next step.';
      $data     =$tem;
    } 
    else{ 

      $response =false;
      $message  ='Application list not found';
      $data     =null;
   }

  $response= array('Response'=>$response,'Message'=>$message,'Data'=>$data);
  echo json_encode($response); 

 
}  
                  
?>