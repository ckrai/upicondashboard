<?php require_once("session.php"); ?>
<?php

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}


//---------------------------- functions----------------------------------------------------

//function for checking user before registration
function check_mobile($con,$mobile){
 $stmt = $con->prepare("SELECT * FROM users WHERE mobile = :mobile");
 $stmt->execute(array(':mobile' => $mobile));
 return $stmt;
}

//function for user registration with
function user_registration($con,$first_name,$last_name,$mobile,$email,$pass,$address,$district,$aadhaar,$role){
  date_default_timezone_set('Asia/Calcutta'); 
  $date=date("Y-m-d H:i:s");
  $stmt = $con->prepare("INSERT INTO users(first_name,last_name,mobile,email,password,address,district,aadhaar,role,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)");
  $stmt->execute(array($first_name,$last_name,$mobile,$email,$pass,$address,$district,$aadhaar,$role,$date));

  $user_id = $con->lastInsertId();
  $district=strtoupper(substr($district, 0,3));
  $code=$district.$user_id;

  create_code($con,$user_id,$code);
  create_activity($con,$user_id,'Account created','Account has been created.');

  return $stmt;
}


function create_code($con,$user_id,$code){
  $stmt =$con->prepare("UPDATE users SET code =:code WHERE id = :id");
  $stmt->execute(array(':id' => $user_id,':code' => $code));    
}

//function for patient loginwith password and mobile
function user_login($con,$mobile,$password){

  $stmt = $con->prepare("SELECT * FROM  users WHERE mobile = :mobile LIMIT 1");
  $stmt->execute(array(':mobile' => $mobile));
  
  $hashpass=md5($password);

  if($stmt->rowCount()>0) {

    $row   = $stmt->fetch();
    if ($row['status']==1) {
      if($hashpass==$row['password']) {  

      $user[] = array('id'=>$row['id'],'code'=>$row['code'],'first_name'=>$row['first_name'],'last_name'=>$row['last_name'],
                      'mobile'=>$row['mobile'],'status'=>$row['status'],'role'=>$row['role']);

      create_activity($con,$row['id'],'Log in','Login successfully.');

      return $user;
    }
    else {
      create_activity($con,$row['id'],'Log in','Entered wrong password.');
      return 1;
    }
    }
    else{
      return 0;
    }
  }
  else {
    return 2;
  }
}


//function for creating login sessions
function create_activity($con,$user_id,$type,$activity){
  date_default_timezone_set('Asia/Calcutta'); 
  $date=date("Y-m-d H:i:s");
  $stmt = $con->prepare("INSERT INTO activities(u_id,type,activity,created_at) VALUES(?,?,?,?)");
  $stmt->execute(array($user_id,$type,$activity,$date));

}

//function for creating login sessions
function create_login_session($con,$user_id,$user_name,$device){
  date_default_timezone_set('Asia/Calcutta'); 
  $date=date("Y-m-d H:i:s");
  $session=md5($date);
  $stmt = $con->prepare("INSERT INTO login_sessions(u_id,u_name,u_device,u_session) VALUES(?,?,?,?)");
  $stmt->execute(array($user_id,$user_name,$device,$session));

}

//function for getting user list
function get_user_list($con) {
  $stmt = $con->prepare("SELECT * FROM users ORDER BY first_name ASC");
  $stmt->execute();
  return $stmt;
}


//function to update user status
function update_user($con,$user_id,$user_status){
  $stmt =$con->prepare("UPDATE users SET status =:status WHERE id = :id");
  $stmt->execute(array(':id' => $user_id,':status' => $user_status));
  return $stmt;
}


//function to update user profile
function update_user_profile($con,$user_id,$first_name,$last_name,$user_mobile,$password){
  $stmt =$con->prepare("UPDATE users SET first_name =:first_name,last_name=:last_name,mobile=:mobile WHERE id = :id");
  $stmt->execute(array(':id' => $user_id,':first_name' => $first_name,':last_name' => $last_name,':mobile' => $user_mobile));
  return $stmt;
}

//function to get unit profile
function get_user_profile($con,$user_id){
  $stmt = $con->prepare("SELECT * FROM users WHERE id=:id");
  $stmt->execute(array(':id' => $user_id));
  return $stmt;
}


//function for getting application list
function get_applications($con,$user_id,$status,$role) {
  if($role=='Admin' || $role='Super Admin'){
     $stmt = $con->prepare("SELECT * FROM applications ORDER BY created_at ASC");
     $stmt->execute();
  }
  else{
    $stmt = $con->prepare("SELECT * FROM applications WHERE added_by=:added_by ORDER BY created_at ASC");
     $stmt->execute(array(':added_by' => $user_id));

  }
  
  return $stmt;
}


//function for getting audit list
function get_udit($con,$user_id,$status,$role) {
  if($role=='Admin' || $role='Super Admin'){
     $stmt = $con->prepare("SELECT * FROM audits ORDER BY created_at DESC");
     $stmt->execute();
  }
  else{
    $stmt = $con->prepare("SELECT * FROM audits WHERE u_id=:u_id ORDER BY created_at DESC");
     $stmt->execute(array(':u_id' => $user_id));

  }
  
  return $stmt;
}


//function for adding new application
function add_new_application($con,$user_id,$ro_code,$first_name,$last_name,$father_name,$gender,$dob,$marital,$mobile,$category,$minority,$pwd,$aadhaar,$voter,$locality,$village,$district,$state,$pincode,$same_district,$same_state){

  date_default_timezone_set('Asia/Calcutta'); 
  $date=date("Y-m-d H:i:s");

  $stmt = $con->prepare("INSERT INTO applications(ro_code,first_name,last_name,father_name,gender,dob,marital,mobile,category,minority,pwd,aadhaar,voter,locality,village,district,state,pincode,same_district,same_state,application_status,added_by,created_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
  $stmt->execute(array($ro_code,$first_name,$last_name,$father_name,$gender,$dob,$marital,$mobile,$category,$minority,$pwd,$aadhaar,$voter,$locality,$village,$district,$state,$pincode,$same_district,$same_state,'Pending',$user_id,$date));
  return $stmt;
}



//function for adding new audit
function add_new_audit($con,$user_id,$b_name,$b_mobile,$b_est_year,$b_address,$b_district,$b_state,$b_pincode,$b_udyog_no,$b_premises,$b_nature_operation,$b_unit_type,$b_nature_of_job,$b_employment_type,
                              $b_vend,$b_supplier){
                                  
    date_default_timezone_set('Asia/Calcutta'); 
    $date=date("Y-m-d H:i:s");

  $stmt = $con->prepare("INSERT INTO audits(u_id,business_name,contact_number,establishment_year,address,district,state,pincode,udyog_number,business_premises,nature_of_operation,type_of_unit,nature_of_job,employment_type,sv_agreement,suppliers_increase,created_at)
    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
  $stmt->execute(array($user_id,$b_name,$b_mobile,$b_est_year,$b_address,$b_district,$b_state,$b_pincode,$b_udyog_no,$b_premises,$b_nature_operation,$b_unit_type,$b_nature_of_job,$b_employment_type,
                              $b_vend,$b_supplier,$date));
  return $stmt;               
                                  
                                  
                              }

































//function to get unit details
function get_unit_details($con,$unit_account){
  $stmt = $con->prepare("SELECT unit_name,connection_no,owner_name,district,half_hp,one_hp,amount FROM tbl_units WHERE connection_no=:connection_no");
  $stmt->execute(array(':connection_no' => $unit_account));
  return $stmt;
}

//function to add new unit
function add_unit($con,$unit_name,$unit_account,$unit_owner,$unit_district,$unit_half_hp,$unit_one_hp,$unit_amount){
  $stmt = $con->prepare("INSERT INTO tbl_units(unit_name,connection_no,owner_name,district,half_hp,one_hp,amount) VALUES(?,?,?,?,?,?,?)");
  $stmt->execute(array($unit_name,$unit_account,$unit_owner,$unit_district,$unit_half_hp,$unit_one_hp,$unit_amount));
  return $stmt;
}





//function for add survey
function update_unit($con,$unit_id,$user_id,$unit_contact,$unit_latitude, $unit_longitude,$unit_address,$image_name,$tana_machine,$winder,$doubler,$calender,$bobin_winder,$reeling_machine,$other_upkaran,$weavers,$avg_consumption){


  $stmt =$con->prepare("UPDATE tbl_units SET contact_no =:contact_no,
                                             address=:address,
                                             latitude=:latitude,
                                             longitude=:longitude,
                                             image=:image,
                                             tana_machine=:tana_machine,
                                             winder=:winder,
                                             doubler=:doubler,
                                             calender=:calender,
                                             bobin_winder=:bobin_winder,
                                             reeling_machine=:reeling_machine,
                                             other_upkaran=:other_upkaran,
                                             weavers=:weavers,
                                             avg_consumption=:avg_consumption,
                                             verify_by=:verify_by WHERE id = :id");
  $stmt->execute(array(':id' => $unit_id,':contact_no' => $unit_contact,':address' => $unit_address,':latitude' => $unit_latitude,':longitude' => $unit_longitude,':image' => $image_name,':tana_machine' => $tana_machine,':winder' => $winder,':doubler' => $doubler,':calender' => $calender,':bobin_winder' => $bobin_winder,':reeling_machine' => $reeling_machine,':other_upkaran' => $other_upkaran,':weavers' => $weavers,':avg_consumption' => $avg_consumption,':verify_by' => $user_id));
  return $stmt;

}



//function to update user status
function update_unit_status($con,$unit_id,$user_id,$unit_status,$unit_comment){
  $stmt =$con->prepare("UPDATE tbl_units SET is_verified =:is_verified,comment=:comment WHERE id = :id");
  $stmt->execute(array(':id' => $unit_id,':is_verified' => $unit_status,':comment' => $unit_comment));
  return $stmt;
}

//function for adding powerloom
function add_powerloom($con,$unit_id,$user_id,$unit_hp,$image_name){
  $stmt = $con->prepare("INSERT INTO tbl_unitpls(unit_id,unit_hp,pl_image) VALUES(?,?,?)");
  $stmt->execute(array($unit_id,$unit_hp,$image_name));
  return $stmt;

}


//function for getting powerlom list
function getunit_pl_list($con,$unit_id,$unit_pl){
  $stmt = $con->prepare("SELECT * FROM tbl_unitpls WHERE status=:status AND unit_id=:unit_id AND unit_hp=:unit_hp  ORDER BY id desc");
  $stmt->execute(array(':status' => 1,':unit_id' => $unit_id,':unit_hp' => $unit_pl));
  return $stmt;
}

//function for getting unit list
function get_user_unit_list($con,$u_id,$user_role,$user_district,$unit_status) {
  if ($user_role=='Admin') {

    if ($unit_status=='All') {
     $stmt = $con->prepare("SELECT * FROM tbl_units ORDER BY district asc");
     $stmt->execute();
    }
    else if ($unit_status=='FullVerified') {
     $stmt = $con->prepare("SELECT * FROM tbl_units WHERE status=:status AND is_verified ='1' ORDER BY updated_at desc");
     $stmt->execute(array(':status' => 1));
    }
    else if ($unit_status=='PartiallyVerified') {
     $stmt = $con->prepare("SELECT * FROM tbl_units WHERE status=:status AND verify_by!='0' AND is_verified ='0' ORDER BY updated_at desc");
     $stmt->execute(array(':status' => 1));
    }
    else if ($unit_status=='Pending') {
     $stmt = $con->prepare("SELECT * FROM tbl_units WHERE status=:status AND verify_by ='0'");
     $stmt->execute(array(':status' => 1));
    }
    
  }

  else{

    if ($unit_status=='All') {
     $stmt = $con->prepare("SELECT * FROM tbl_units WHERE status=:status AND district='$user_district'");
     $stmt->execute(array(':status' => 1));
    }
    else if ($unit_status=='FullVerified') {
     $stmt = $con->prepare("SELECT * FROM tbl_units WHERE status=:status AND verify_by=:verify_by AND is_verified=:is_verified ORDER BY updated_at desc");
     $stmt->execute(array(':status' => 1,':verify_by' => $u_id,':is_verified' =>'1'));
    }
    else if ($unit_status=='Pending') {
     $stmt = $con->prepare("SELECT * FROM tbl_units WHERE status=:status AND district='$user_district' AND verify_by ='0'");
     $stmt->execute(array(':status' => 1));
    }
    else if ($unit_status=='PartiallyVerified') {
     $stmt = $con->prepare("SELECT * FROM tbl_units WHERE status=:status AND verify_by=:verify_by AND is_verified=:is_verified ORDER BY updated_at desc");
     $stmt->execute(array(':status' => 1,':verify_by' => $u_id,':is_verified' =>'0'));
    }
   

   // $stmt = $con->prepare("SELECT * FROM tbl_units WHERE status=:status AND verify_by=:verify_by ORDER BY district asc");
   // $stmt->execute(array(':status' => 1,':verify_by' => $u_id));
  }
  
  return $stmt;
}




//function for changing user password 
function change_password($con,$user_id,$old_password,$new_password){

   $hashpass=md5($old_password);
   
  $stmt = $con->prepare("SELECT * FROM tbl_users WHERE id =:id  LIMIT 1");
  $stmt->execute(array(':id' => $user_id));
  $row = $stmt->fetch(PDO::FETCH_ASSOC);

  if($stmt->rowCount()==1){

      if($hashpass== $row['password']){

        $newpass = md5($new_password);

        $stmt =$con->prepare("UPDATE tbl_users SET password =:password WHERE id = :id");
        $stmt->execute(array(':id' => $user_id,':password' => $newpass));
        return 1;
        
      }
    else {
      return 2;
    }
    
  }

}

//function for  count
function get_count($con,$user_id,$user_role,$user_district){

    if ($user_role=='Admin') {
     $stmt = $con->prepare("SELECT 
                            (select count(id) from users where role!='Admin') as total_user,
                            (select count(id) from audits) as total_audits,
                            (select count(id) from audits where status='1') as approved_audits,
                            (select count(id) from audits where status = '0') as pending_audits,
                            (select count(id) from audits where nature_of_operation = 'Micro') as total_micro,
                            (select count(id) from audits where nature_of_operation = 'Small') as total_small,
                            (select count(id) from audits where nature_of_operation = 'Medium') as total_medium");
     $stmt->execute();
    }
    else{
      $stmt = $con->prepare("SELECT 
                             (select count(id) from users where role!='Admin') as total_user,
                            (select count(id) from audits) as total_audits,
                            (select count(id) from audits where status='1') as approved_audits,
                            (select count(id) from audits where status = '0') as pending_audits,
                            (select count(id) from audits where nature_of_operation = 'Micro') as total_micro,
                            (select count(id) from audits where nature_of_operation = 'Small') as total_small,
                            (select count(id) from audits where nature_of_operation = 'Medium') as total_medium");
     $stmt->execute();
    }

    
    return $stmt;

}
